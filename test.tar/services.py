import os
from lxml import etree
from datetime import datetime
from werkzeug.utils import secure_filename
from models import db, Invoice, Boleto, User
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.graphics.barcode import code128, common
import io

class CnabService:
    @staticmethod
    def format_text(text, length):
        return str(text)[:length].ljust(length, ' ')

    @staticmethod
    def format_num(num, length):
        return str(int(num)).zfill(length)

    @staticmethod
    def generate_santander_240(boletos, user):
        # CNAB 240 Structure (Simplified)
        lines = []
        
        # File Header (Header de Arquivo)
        header = f"03300000         2{CnabService.format_text(user.username, 30)}{CnabService.format_text('SANTANDER', 30)}{datetime.now().strftime('%d%m%Y')}"
        # Pad to 240
        header = header.ljust(240, ' ')
        lines.append(header)
        
        # Batch Header (Header de Lote)
        batch_header = f"03300011R01  040 {CnabService.format_text(user.username, 30)}"
        batch_header = batch_header.ljust(240, ' ')
        lines.append(batch_header)
        
        seq = 1
        for boleto in boletos:
            # Segment P (Required for Register)
            seg_p = f"03300013{CnabService.format_num(seq, 5)}P 01"
            seg_p += CnabService.format_num(boleto.nosso_numero, 13) # Nosso Numero
            seg_p += CnabService.format_num(boleto.amount * 100, 15) # Valor
            seg_p = seg_p.ljust(240, ' ')
            lines.append(seg_p)
            
            # Segment Q (Sacado Data)
            seg_q = f"03300013{CnabService.format_num(seq+1, 5)}Q 01"
            seg_q += CnabService.format_text(boleto.sacado_name, 40)
            seg_q = seg_q.ljust(240, ' ')
            lines.append(seg_q)
            
            seq += 2

        # Batch Trailer
        batch_trailer = f"03300015{CnabService.format_num(seq + 2, 6)}{CnabService.format_num(len(boletos) * 2 + 2, 6)}"
        batch_trailer = batch_trailer.ljust(240, ' ')
        lines.append(batch_trailer)
        
        # File Trailer
        file_trailer = f"03399999         {CnabService.format_num(1, 6)}{CnabService.format_num(len(lines)+1, 6)}"
        file_trailer = file_trailer.ljust(240, ' ')
        lines.append(file_trailer)
        
        return "\r\n".join(lines)

    @staticmethod
    def generate_bmp_400(boletos, user):
        # CNAB 400 Structure (Simplified Standard)
        lines = []
        
        # Header
        header = f"01REMESSA01COBRANCA       {CnabService.format_text(user.agency, 4)}{CnabService.format_text(user.account, 8)}      {CnabService.format_text(user.username, 30)}BMP BANCO      {datetime.now().strftime('%d%m%y')}"
        header = header.ljust(400, ' ')
        lines.append(header)
        
        seq = 1
        for boleto in boletos:
            # Type 1 - Transaction
            line = f"1{CnabService.format_text(user.agency, 5)}{CnabService.format_text(user.account, 8)}"
            line += CnabService.format_num(boleto.nosso_numero, 11) # Nosso Numero
            line += CnabService.format_num(boleto.amount * 100, 13) # Value
            line += boleto.due_date.strftime('%d%m%y')
            line += CnabService.format_text(boleto.sacado_name, 40)
            
            line = line.ljust(394, ' ') # Leave space for seq
            line += CnabService.format_num(seq, 6)
            lines.append(line)
            seq += 1
            
        # Trailer
        trailer = f"9{CnabService.format_num(seq, 6)}" # Block 9 is trailer
        trailer = trailer.ljust(400, ' ')
        lines.append(trailer)
        
        return "\r\n".join(lines)

class BoletoBuilder:
    @staticmethod
    def mod11(number, base=9, r=0):
        """
        Calculates Modulo 11 check digit.
        """
        sum_ = 0
        weight = 2
        for n in reversed(str(number)):
            sum_ += int(n) * weight
            weight += 1
            if weight > base:
                weight = 2
        
        res = 11 - (sum_ % 11)
        if res == 10 or res == 11:
            return r
        return res

    @staticmethod
    def mod10(number):
        """
        Calculates Modulo 10 check digit.
        """
        sum_ = 0
        weight = 2
        for n in reversed(str(number)):
            val = int(n) * weight
            if val > 9:
                val = (val // 10) + (val % 10)
            sum_ += val
            weight = 1 if weight == 2 else 2
        
        res = 10 - (sum_ % 10)
        return 0 if res == 10 else res

    @staticmethod
    def calculate_santander_nosso_numero(nosso_numero):
        # Santander format: 12 digits + 1 check digit
        # Example logic (simplified)
        dv = BoletoBuilder.mod11(nosso_numero)
        return f"{nosso_numero}-{dv}"

    @staticmethod
    def generate_pdf(boleto_data, filepath):
        c = canvas.Canvas(filepath, pagesize=A4)
        width, height = A4
        
        # Draw basic boleto lines (Simplified Layout)
        c.setLineWidth(1)
        
        # Header
        c.setFont("Helvetica-Bold", 12)
        c.drawString(10*mm, height - 20*mm, f"{boleto_data['bank_name']} | {boleto_data['bank_code']}")
        c.drawString(150*mm, height - 20*mm, boleto_data['digitable_line'])
        
        # Box 1
        y = height - 30*mm
        c.line(10*mm, y, 200*mm, y)
        c.setFont("Helvetica", 8)
        c.drawString(10*mm, y - 4*mm, "Local de Pagamento")
        c.setFont("Helvetica-Bold", 10)
        c.drawString(10*mm, y - 8*mm, "PAGÁVEL EM QUALQUER BANCO ATÉ O VENCIMENTO")
        c.line(10*mm, y - 10*mm, 200*mm, y - 10*mm)
        
        # Cedente
        c.setFont("Helvetica", 8)
        c.drawString(10*mm, y - 14*mm, "Beneficiário")
        c.setFont("Helvetica", 10)
        c.drawString(10*mm, y - 18*mm, boleto_data['cedente_name'])
        
        # Data Vencimento
        c.line(150*mm, y, 150*mm, y - 30*mm)
        c.setFont("Helvetica", 8)
        c.drawString(152*mm, y - 4*mm, "Vencimento")
        c.setFont("Helvetica-Bold", 10)
        c.drawString(152*mm, y - 9*mm, boleto_data['due_date'].strftime('%d/%m/%Y'))
        
        # Valor
        c.line(150*mm, y - 10*mm, 200*mm, y - 10*mm)
        c.drawString(152*mm, y - 14*mm, "Valor do Documento")
        c.drawString(152*mm, y - 19*mm, f"R$ {boleto_data['amount']:.2f}")

        # Sacado
        y_sacado = y - 50*mm
        c.drawString(10*mm, y_sacado, "Pagador:")
        c.drawString(10*mm, y_sacado - 5*mm, f"{boleto_data['sacado_name']} - {boleto_data['sacado_doc']}")
        
        # Barcode (Placeholder)
        # Using Code128 for simplicity in demo, but Boleto uses Interleaved 2 of 5
        try:
            barcode = code128.Code128(boleto_data['barcode'], barHeight=13*mm, barWidth=0.3*mm)
            barcode.drawOn(c, 10*mm, 20*mm)
        except:
            c.drawString(10*mm, 20*mm, f"BARCODE: {boleto_data['barcode']}")
        
        c.save()

class XmlParser:
    @staticmethod
    def parse_nfe(tree, ns):
        # NFe Namespace
        # Usually {http://www.portalfiscal.inf.br/nfe}
        
        # Find Destinatario (Payer)
        dest = tree.find(f'.//{{{ns}}}dest')
        if dest is None:
            raise ValueError("Destinatario not found in NFe")
            
        name = dest.find(f'{{{ns}}}xNome').text
        
        cnpj = dest.find(f'{{{ns}}}CNPJ')
        cpf = dest.find(f'{{{ns}}}CPF')
        doc = cnpj.text if cnpj is not None else (cpf.text if cpf is not None else '')
        
        # Find Value
        v_nf = tree.find(f'.//{{{ns}}}total/{{{ns}}}ICMSTot/{{{ns}}}vNF')
        amount = float(v_nf.text) if v_nf is not None else 0.0
        
        # Find Date
        dh_emi = tree.find(f'.//{{{ns}}}ide/{{{ns}}}dhEmi')
        d_emi = tree.find(f'.//{{{ns}}}ide/{{{ns}}}dEmi')
        
        date_str = dh_emi.text if dh_emi is not None else (d_emi.text if d_emi is not None else '')
        # Simple ISO date parse (truncated to date)
        if 'T' in date_str:
            issue_date = datetime.strptime(date_str.split('T')[0], '%Y-%m-%d').date()
        else:
            issue_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            
        # Find Number
        n_nf = tree.find(f'.//{{{ns}}}ide/{{{ns}}}nNF')
        number = n_nf.text if n_nf is not None else 'Unknown'
        
        return {
            'sacado_name': name,
            'sacado_doc': doc,
            'amount': amount,
            'issue_date': issue_date,
            'doc_number': number
        }

    @staticmethod
    def parse_cte(tree, ns):
        # CTe logic
        # Find Value
        v_tprest = tree.find(f'.//{{{ns}}}vPrest/{{{ns}}}vTPrest')
        amount = float(v_tprest.text) if v_tprest is not None else 0.0
        
        # Find Date
        dh_emi = tree.find(f'.//{{{ns}}}ide/{{{ns}}}dhEmi')
        date_str = dh_emi.text if dh_emi is not None else ''
        if 'T' in date_str:
            issue_date = datetime.strptime(date_str.split('T')[0], '%Y-%m-%d').date()
        else:
            issue_date = datetime.now().date() # Fallback

        # Find Number
        n_ct = tree.find(f'.//{{{ns}}}ide/{{{ns}}}nCT')
        number = n_ct.text if n_ct is not None else 'Unknown'

        # Payer Logic
        # Try toma3
        toma3 = tree.find(f'.//{{{ns}}}infCteNorm/{{{ns}}}infCarga/{{{ns}}}toma3') 
        # Note: structure might vary, sometimes it is directly under infCte
        if toma3 is None:
             toma3 = tree.find(f'.//{{{ns}}}ide/{{{ns}}}toma3')

        payer_data = {}
        
        if toma3 is not None:
            toma_role = toma3.find(f'{{{ns}}}toma').text
            # 0=Remetente, 1=Expedidor, 2=Recebedor, 3=Destinatario
            role_map = {'0': 'rem', '1': 'exped', '2': 'receb', '3': 'dest'}
            role_tag = role_map.get(toma_role)
            
            if role_tag:
                role_node = tree.find(f'.//{{{ns}}}{role_tag}')
                if role_node is not None:
                    payer_data['name'] = role_node.find(f'{{{ns}}}xNome').text
                    cnpj = role_node.find(f'{{{ns}}}CNPJ')
                    cpf = role_node.find(f'{{{ns}}}CPF')
                    payer_data['doc'] = cnpj.text if cnpj is not None else (cpf.text if cpf is not None else '')
        else:
            # Try toma4
            toma4 = tree.find(f'.//{{{ns}}}ide/{{{ns}}}toma4')
            if toma4 is not None:
                # toma4 explicitly defines the payer
                toma = toma4.find(f'{{{ns}}}toma') # Indicates who
                # But toma4 usually has CNPJ/CPF directly if it's "Outros"?
                # Actually toma4 struct: <toma>4</toma> <CNPJ>...</CNPJ> <xNome>...</xNome>
                payer_data['name'] = toma4.find(f'{{{ns}}}xNome').text
                cnpj = toma4.find(f'{{{ns}}}CNPJ')
                cpf = toma4.find(f'{{{ns}}}CPF')
                payer_data['doc'] = cnpj.text if cnpj is not None else (cpf.text if cpf is not None else '')

        if not payer_data:
            # Fallback to Destinatario if logic fails, but strict logic requires correct mapping
            dest = tree.find(f'.//{{{ns}}}dest')
            if dest:
                payer_data['name'] = dest.find(f'{{{ns}}}xNome').text
                cnpj = dest.find(f'{{{ns}}}CNPJ')
                payer_data['doc'] = cnpj.text if cnpj is not None else ''

        return {
            'sacado_name': payer_data.get('name', 'Unknown'),
            'sacado_doc': payer_data.get('doc', ''),
            'amount': amount,
            'issue_date': issue_date,
            'doc_number': number
        }

    @staticmethod
    def parse_file(filepath):
        try:
            tree = etree.parse(filepath)
            root = tree.getroot()
            # Determine Namespace
            ns = root.tag.split('}')[0].strip('{')
            
            if 'NFe' in root.tag:
                return 'nfe', XmlParser.parse_nfe(tree, ns)
            elif 'CTe' in root.tag:
                return 'cte', XmlParser.parse_cte(tree, ns)
            else:
                return None, None
        except Exception as e:
            print(f"Error parsing XML: {e}")
            return None, None

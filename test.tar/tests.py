import unittest
from app import app, db, User, Invoice, Boleto
from services import CnabService, BoletoBuilder
from datetime import date

class TestFidcSystem(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['WTF_CSRF_ENABLED'] = False # Disable CSRF for testing
        self.app = app.test_client()
        with app.app_context():
            db.create_all()
            user = User(username='test_cedente', password_hash='hash', role='cedente', bank_code='033')
            db.session.add(user)
            db.session.commit()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_cnab_santander_format(self):
        user = User(username='TestUser', agency='1234', account='12345678', wallet='101')
        boleto = Boleto(
            nosso_numero='123456789012', 
            amount=100.50, 
            sacado_name='Test Sacado',
            due_date=date(2023, 12, 31)
        )
        content = CnabService.generate_santander_240([boleto], user)
        # Check line length
        lines = content.split('\r\n')
        self.assertEqual(len(lines[0]), 240)
        self.assertIn('SANTANDER', lines[0])

    def test_cnab_bmp_format(self):
        user = User(username='TestUserBMP', agency='1234', account='12345678')
        boleto = Boleto(
            nosso_numero='12345678901', 
            amount=200.00, 
            sacado_name='Test Sacado BMP',
            due_date=date(2023, 12, 31)
        )
        content = CnabService.generate_bmp_400([boleto], user)
        lines = content.split('\r\n')
        self.assertEqual(len(lines[0]), 400)
        self.assertIn('BMP BANCO', lines[0])

    def test_santander_nosso_numero_logic(self):
        # Just check if it returns a string with hyphen
        nn = BoletoBuilder.calculate_santander_nosso_numero(123)
        self.assertTrue('-' in nn)

if __name__ == '__main__':
    unittest.main()
